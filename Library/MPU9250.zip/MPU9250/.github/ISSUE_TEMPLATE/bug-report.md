---
name: Bug Report
about: Please fill out all sections
title: ''
labels: ''
assignees: ''

---

## Environment

IDE (Arduino IDE, PlatformIO, etc.) : 
Board/MCU (Arduino Uno, ESP32, etc.): 
Board Firmware Version (see board manager): 
MPU-9250 Library Version: 

## Problem Summary


## Problem Details


## Reproducible & Minimal & Compilable Code
